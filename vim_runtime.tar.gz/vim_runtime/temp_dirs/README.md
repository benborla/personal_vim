Used for temp dirs/files such as undodir
